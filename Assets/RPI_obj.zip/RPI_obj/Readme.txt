Created by Scott Richards
www.srcgi.co.uk

You may use this model for any non-commercial (non-profit) project,
providing you give credit to me. If you wish to use this model commercially,
please message me through my website and we can discuss this.

Additionally, please do not distribute these file in any form without obtaining
permission from me first. You are allowed to present this model on your website,
providing your users are sent to www.srcgi.co.uk/rpi-model to download the files.

Websites with permission to distribute this model:
www.srcgi.co.uk
www.raspberryconnect.com